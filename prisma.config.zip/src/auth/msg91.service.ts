import { BadGatewayException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class Msg91Service {
  constructor(private readonly config: ConfigService) {}

  async sendOtp(mobileWithCountryCode: string, otp: string): Promise<void> {
    const authKey = this.config.getOrThrow<string>('MSG91_AUTH_KEY');
    const templateId = this.config.getOrThrow<string>('MSG91_OTP_TEMPLATE_ID');
    const expiry = Number(this.config.get<string>('OTP_EXPIRY_MINUTES') || 5);

    const params = new URLSearchParams({
      template_id: templateId,
      mobile: mobileWithCountryCode,
      authkey: authKey,
      otp,
      otp_expiry: String(expiry),
    });

    const response = await fetch(`https://control.msg91.com/api/v5/otp?${params.toString()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    let body: any = null;
    try {
      body = await response.json();
    } catch {
      body = null;
    }

    if (!response.ok || body?.type === 'error') {
      throw new BadGatewayException({
        message: 'MSG91 could not send OTP',
        provider: body,
      });
    }
  }
}
